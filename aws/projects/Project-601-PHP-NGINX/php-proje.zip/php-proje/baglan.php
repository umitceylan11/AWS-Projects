<?php

define('VT_HOST', 'database-1.cyxf98jusd1m.us-east-1.rds.amazonaws.com');
define('VT_KULLANICI_ADI', 'admin');
define('VT_SIFRE', '123ewq123');
define('VT_VERITABANI', 'testdb');

mysql_connect(VT_HOST, VT_KULLANICI_ADI, VT_SIFRE);
mysql_select_db(VT_VERITABANI);
mysql_query("SET NAMES utf8");